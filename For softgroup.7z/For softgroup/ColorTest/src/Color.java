
public class Color {
	protected int red;
	protected int green;
	protected int blue;
}
